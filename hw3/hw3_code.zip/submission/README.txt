HW3 DQN
Ted Xiao, SID 24452530

To run DQN on Pong with pixels, run the expected: `python run_dqn_atari.py`
To run DQN on Pong with RAM, adjust the designed learning rate (AKA learning rate multipler) on line 133 of "run_dqn_ram.py" and then run: `python run_dqn_ram.py`

To generate the plots: `python plotting.py`

The data from various trials I ran are in respective folders labeled with their LR and whether they were on RAM or pixels.